from django.urls import path
from . import views

urlpatterns =[
	path('',views.index, name='index'),
]

urlpatterns += [
    path('representadas/', views.RepresentadaListView.as_view(), name='representadas'),
    path('representada/<int:pk>', views.RepresentadaDetailView.as_view(), name='representada-detail'),
    path('representada/create/', views.RepresentadaCreate.as_view(), name='representada-create'),
    path('representada/<int:pk>/update/', views.RepresentadaUpdate.as_view(), name='representada-update'),
    path('representada/<int:pk>/delete/', views.RepresentadaDelete.as_view(), name='representada-delete'),
]


urlpatterns += [
    path('produtos/', views.ProdutoListView.as_view(), name='produtos'),
    path('produto/<int:pk>', views.ProdutoDetailView.as_view(), name='produto-detail'),
    path('produto/create/', views.ProdutoCreate.as_view(), name='produto-create'),
    path('produto/<int:pk>/update/', views.ProdutoUpdate.as_view(), name='produto-update'),
    path('produto/<int:pk>/delete/', views.ProdutoDelete.as_view(), name='produto-delete'),
]