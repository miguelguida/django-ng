from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(Representada)
admin.site.register(Produto)