from django.db import models
from django.urls import reverse  # To generate URLS by reversing URL patterns
import uuid  # Required for unique book instances
from datetime import date


# Create your models here.
class Representada(models.Model):
    """Model representing a Language (e.g. English, French, Japanese, etc.)"""
    nome = models.CharField(max_length=200,
                            help_text="Nome da representada")
    contato = models.CharField(max_length=200)    
    cnpj = models.CharField(max_length=200)
    inscEstadual = models.CharField(max_length=200)
    inscMunicipal = models.CharField(max_length=200)
    estado = models.CharField(max_length=200)
    cidade = models.CharField(max_length=200)
    cep = models.CharField(max_length=200)
    endereco = models.CharField(max_length=200)
    bairro = models.CharField(max_length=200)
    telefone = models.CharField(max_length=200)
    celular = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    linha = models.CharField(max_length=200)
    comissao = models.CharField(max_length=200)
    ipi = models.CharField(max_length=200)

    def get_absolute_url(self):
        """Returns the url to access a particular author instance."""
        return reverse('representada-detail', args=[str(self.id)])

    def __str__(self):
        """String for representing the Model object (in Admin site etc.)"""
        return self.nome


# Create your models here.
class Produto(models.Model):
    """Model representing a Language (e.g. English, French, Japanese, etc.)"""
    nome = models.CharField(max_length=200,
                            help_text="Nome do produto")
    valor = models.CharField(max_length=200)    
    referencia = models.CharField(max_length=200)
    codRepresentada = models.CharField(max_length=200)
    representada = models.ForeignKey('Representada', on_delete=models.SET_NULL, null=True)
    observacoes = models.CharField(max_length=200)
    

    def get_absolute_url(self):
        """Returns the url to access a particular author instance."""
        return reverse('produto-detail', args=[str(self.id)])

    def __str__(self):
        """String for representing the Model object (in Admin site etc.)"""
        return self.nome