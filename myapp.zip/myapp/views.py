from django.shortcuts import render
from django.http import HttpResponse 
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.urls import reverse
from django.urls import reverse_lazy

import datetime


from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView

from django.contrib.auth.mixins import PermissionRequiredMixin

from .models import *

# Create your views here.
from django.contrib.auth.decorators import login_required

@login_required
def index(request):
	return render(request, 'index.html')

class RepresentadaListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Representada
    paginate_by = 10


class RepresentadaDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Representada


# Classes created for the forms challenge
class RepresentadaCreate( CreateView):
    model = Representada
    fields = '__all__'
    # permission_required = 'catalog.can_mark_returned'


class RepresentadaUpdate( UpdateView):
    model = Representada
    fields = '__all__'
    # permission_required = 'catalog.can_mark_returned'


class RepresentadaDelete( DeleteView):
    model = Representada
    success_url = reverse_lazy('representadas')
    # permission_required = 'catalog.can_mark_returned'



class ProdutoListView(generic.ListView):
    """Generic class-based view for a list of books."""
    model = Produto
    paginate_by = 10


class ProdutoDetailView(generic.DetailView):
    """Generic class-based detail view for a book."""
    model = Produto


# Classes created for the forms challenge
class ProdutoCreate( CreateView):
    model = Produto
    fields = '__all__'
    # permission_required = 'catalog.can_mark_returned'


class ProdutoUpdate( UpdateView):
    model = Produto
    fields = '__all__'
    # permission_required = 'catalog.can_mark_returned'


class ProdutoDelete( DeleteView):
    model = Produto
    success_url = reverse_lazy('produtos')
    # permission_required = 'catalog.can_mark_returned'